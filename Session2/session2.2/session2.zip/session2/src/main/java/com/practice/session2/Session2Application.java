package com.practice.session2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Session2Application {

	public static void main(String[] args) {
		SpringApplication.run(Session2Application.class, args);
	}

}
